# CLEARFRAME AI

A browser-based video inspection and cleanup workspace.

## Features
- Upload a local video and preview it in the browser.
- Experimental visual scan that suggests a likely overlay region for human review.
- Manual drag-to-select regions.
- Browser-side export with blur, pixelate, or cover processing.
- Basic byte-string inspection for selected metadata/provenance markers.

## Important limitations
- The visual scan is a heuristic, not a trained AI watermark detector. It can miss watermarks and produce false positives.
- Metadata inspection is a lightweight marker scan, not a full C2PA validator. It cannot reliably detect invisible watermark systems such as SynthID. No match does not prove that a file has no provenance data or AI watermark.
- Export uses the browser's MediaRecorder and creates WebM. Browser codec support varies. Audio is included where the browser exposes the video's audio tracks.
- Blur, pixelation, and cover are not generative inpainting and do not reconstruct hidden pixels.
- Processing happens locally in the browser. Large videos may exceed available device memory, especially on phones.
- Use only on videos you own or are authorised to edit. The app does not attempt to remove invisible authenticity/provenance signals.

## Local development
```bash
npm install
npm run dev
```

## GitHub Pages
The Vite base path is configured for `/clearframe-ai/` when `GITHUB_PAGES=true`.
The repository's existing workflow should set this variable during build.
