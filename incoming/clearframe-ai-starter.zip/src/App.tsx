import { useEffect, useRef, useState } from 'react'
import {
  Aperture, ArrowUpRight, BadgeCheck, Check, ChevronDown, CircleHelp,
  Clapperboard, CloudUpload, FileVideo, Fingerprint, Info, LockKeyhole,
  Play, ScanSearch, ShieldCheck, Sparkles, Upload, X
} from 'lucide-react'

type Mode = 'cleanup' | 'inspect'

function formatSize(bytes: number) {
  if (!bytes) return '—'
  const units = ['B', 'KB', 'MB', 'GB']
  const index = Math.min(Math.floor(Math.log(bytes) / Math.log(1024)), 3)
  return `${(bytes / Math.pow(1024, index)).toFixed(index ? 1 : 0)} ${units[index]}`
}

export default function App() {
  const inputRef = useRef<HTMLInputElement>(null)
  const videoRef = useRef<HTMLVideoElement>(null)
  const stageRef = useRef<HTMLDivElement>(null)
  const [mode, setMode] = useState<Mode>('cleanup')
  const [file, setFile] = useState<File | null>(null)
  const [videoUrl, setVideoUrl] = useState('')
  const [dragging, setDragging] = useState(false)
  const [region, setRegion] = useState<{x:number;y:number;w:number;h:number} | null>(null)
  const [drawing, setDrawing] = useState(false)
  const [start, setStart] = useState<{x:number;y:number} | null>(null)
  const [notice, setNotice] = useState('')

  useEffect(() => () => { if (videoUrl) URL.revokeObjectURL(videoUrl) }, [videoUrl])

  function loadFile(next: File | undefined) {
    if (!next) return
    if (!next.type.startsWith('video/')) {
      setNotice('Please choose a video file (MP4, MOV or WebM).')
      return
    }
    if (next.size > 500 * 1024 * 1024) {
      setNotice('This starter version supports files up to 500 MB.')
      return
    }
    setNotice('')
    setFile(next)
    setRegion(null)
    setVideoUrl(URL.createObjectURL(next))
  }

  function point(e: React.PointerEvent<HTMLDivElement>) {
    const rect = stageRef.current?.getBoundingClientRect()
    if (!rect) return null
    return {
      x: Math.max(0, Math.min(100, ((e.clientX - rect.left) / rect.width) * 100)),
      y: Math.max(0, Math.min(100, ((e.clientY - rect.top) / rect.height) * 100)),
    }
  }

  function beginDraw(e: React.PointerEvent<HTMLDivElement>) {
    if (!file || mode !== 'cleanup') return
    const p = point(e)
    if (!p) return
    e.currentTarget.setPointerCapture(e.pointerId)
    setStart(p)
    setRegion({x:p.x,y:p.y,w:0,h:0})
    setDrawing(true)
  }
  function moveDraw(e: React.PointerEvent<HTMLDivElement>) {
    if (!drawing || !start) return
    const p = point(e)
    if (!p) return
    setRegion({x:Math.min(start.x,p.x),y:Math.min(start.y,p.y),w:Math.abs(p.x-start.x),h:Math.abs(p.y-start.y)})
  }
  function endDraw() {
    setDrawing(false)
    setStart(null)
  }

  return (
    <div className="app-shell">
      <header className="topbar">
        <a className="brand" href="#home" aria-label="CLEARFRAME AI home">
          <span className="brand-mark"><Aperture size={20}/></span>
          <span>CLEARFRAME<span className="brand-ai">AI</span></span>
        </a>
        <nav className="top-nav"><a className="active" href="#studio">Studio</a><a href="#how">How it works</a><a href="#principles">Our principles</a></nav>
        <div className="top-actions"><span className="private-pill"><LockKeyhole size={12}/> Private workspace</span><button className="help-btn" title="Help"><CircleHelp size={18}/></button></div>
      </header>

      <main id="studio">
        <section className="hero">
          <div className="eyebrow"><span className="eyebrow-dot"/> VIDEO WORKSPACE <span className="eyebrow-line"/></div>
          <h1>Your footage.<br/><span>Clearer by design.</span></h1>
          <p className="hero-copy">Inspect video provenance and prepare clean edits to footage you own or have permission to modify.</p>
        </section>

        <div className="workspace">
          <aside className="side-panel">
            <div className="panel-label">WORKSPACE</div>
            <button className={`mode-card ${mode === 'cleanup' ? 'selected' : ''}`} onClick={() => setMode('cleanup')}>
              <span className="mode-icon"><Clapperboard size={18}/></span>
              <span className="mode-copy"><b>Visible watermark</b><small>Select an area to prepare an edit</small></span>
              {mode === 'cleanup' && <span className="selected-check"><Check size={13}/></span>}
            </button>
            <button className={`mode-card ${mode === 'inspect' ? 'selected' : ''}`} onClick={() => setMode('inspect')}>
              <span className="mode-icon purple"><Fingerprint size={18}/></span>
              <span className="mode-copy"><b>Provenance check</b><small>Inspect available authenticity signals</small></span>
              {mode === 'inspect' && <span className="selected-check"><Check size={13}/></span>}
            </button>
            <div className="side-divider"/>
            <div className="panel-label">YOUR FILE</div>
            {file ? <div className="file-card"><span className="file-icon"><FileVideo size={18}/></span><span className="file-meta"><b>{file.name}</b><small>{formatSize(file.size)} · Video</small></span><button onClick={() => {setFile(null);setVideoUrl('');setRegion(null)}} className="remove-file" aria-label="Remove file"><X size={15}/></button></div> : <div className="empty-file">No video added yet</div>}
            <div className="side-note"><ShieldCheck size={17}/><span><b>Local-first workspace</b><small>Your selected video stays in this browser in this starter build.</small></span></div>
            <div className="side-bottom"><span className="status-dot"/> SYSTEM READY <span className="version">BETA 0.1</span></div>
          </aside>

          <section className="editor">
            <div className="editor-head"><div><span className="editor-kicker">EDITOR</span><h2>{mode === 'cleanup' ? 'Visible watermark workspace' : 'AI provenance inspection'}</h2></div><button className="format-btn"><span className="green-dot"/> {file ? 'VIDEO LOADED' : 'AWAITING VIDEO'} <ChevronDown size={14}/></button></div>
            {!file ? (
              <div className={`upload-zone ${dragging ? 'dragging' : ''}`} onDragOver={e => {e.preventDefault();setDragging(true)}} onDragLeave={() => setDragging(false)} onDrop={e => {e.preventDefault();setDragging(false);loadFile(e.dataTransfer.files[0])}}>
                <div className="upload-orbit"><div className="upload-inner"><CloudUpload size={27}/></div><span className="orbit-dot one"/><span className="orbit-dot two"/></div>
                <h3>Bring your video into focus.</h3>
                <p>Drop a video here, or browse your device to get started.</p>
                <button className="primary-btn" onClick={() => inputRef.current?.click()}><Upload size={16}/> Choose a video</button>
                <div className="file-types">MP4 <i/> MOV <i/> WEBM <i/> UP TO 500 MB</div>
                <input ref={inputRef} type="file" accept="video/mp4,video/quicktime,video/webm,video/*" hidden onChange={e => loadFile(e.target.files?.[0])}/>
              </div>
            ) : (
              <div className="video-workspace">
                <div className="video-stage" ref={stageRef} onPointerDown={beginDraw} onPointerMove={moveDraw} onPointerUp={endDraw} onPointerCancel={endDraw}>
                  <video ref={videoRef} src={videoUrl} controls playsInline />
                  {mode === 'cleanup' && <div className="selection-layer">
                    {region && region.w > 0.5 && region.h > 0.5 ? <div className="selection-box" style={{left:`${region.x}%`,top:`${region.y}%`,width:`${region.w}%`,height:`${region.h}%`}}><span>SELECTED AREA</span></div> : <div className="selection-hint"><ScanSearch size={16}/> Drag to mark a watermark area</div>}
                  </div>}
                </div>
                <div className="video-tools"><span><b>{file.name}</b> · {formatSize(file.size)}</span><button onClick={() => {setFile(null);setVideoUrl('');setRegion(null)}}>Replace video</button></div>
                {mode === 'cleanup' ? <div className="tool-info"><Info size={16}/><span>{region && region.w > 1 && region.h > 1 ? 'Area selected. Automatic removal and reconstruction are not enabled in this starter build yet.' : 'Drag across the video to mark the visible watermark you want to work on.'}</span></div> : <div className="tool-info purple-info"><Fingerprint size={16}/><span>Provenance inspection is a planned capability. This build does not yet verify C2PA credentials or invisible watermark signals.</span></div>}
              </div>
            )}
            {notice && <div className="notice"><Info size={15}/>{notice}</div>}
            <div className="editor-footer"><span><LockKeyhole size={13}/> No upload to a server in this build</span><span>Built for responsible editing <ArrowUpRight size={13}/></span></div>
          </section>

          <aside className="insight-panel">
            <div className="insight-head"><span className="insight-icon"><Sparkles size={16}/></span><div><b>Workspace guide</b><small>YOUR NEXT MOVE</small></div></div>
            {mode === 'cleanup' ? <><div className="guide-step"><span className="step-num">01</span><div><b>Add your footage</b><p>Choose a video file from your device.</p></div><BadgeCheck size={16} className={file ? 'step-done' : 'step-muted'}/></div><div className="guide-step"><span className="step-num">02</span><div><b>Mark the watermark</b><p>Drag over the visible mark in the preview.</p></div><span className="step-muted">—</span></div><div className="guide-step"><span className="step-num">03</span><div><b>Review the edit</b><p>Removal and reconstruction tools are coming next.</p></div><span className="step-muted">—</span></div></> : <><div className="guide-step"><span className="step-num">01</span><div><b>Add your footage</b><p>Load the video you want to inspect.</p></div><BadgeCheck size={16} className={file ? 'step-done' : 'step-muted'}/></div><div className="guide-step"><span className="step-num">02</span><div><b>Inspect provenance</b><p>Credential and watermark checks are planned.</p></div><span className="step-muted">—</span></div><div className="guide-step"><span className="step-num">03</span><div><b>Understand the result</b><p>Review signals without stripping authenticity data.</p></div><span className="step-muted">—</span></div></>}
            <div className="principle-card"><div className="principle-top"><ShieldCheck size={16}/><span>OUR COMMITMENT</span></div><b>Keep the story.<br/>Respect the source.</b><p>We’re building tools for responsible video editing — not for hiding where media came from.</p></div>
            <a className="learn-link" href="#principles">Explore our principles <ArrowUpRight size={14}/></a>
          </aside>
        </div>

        <section className="bottom-strip" id="how"><div className="strip-item"><span className="strip-icon"><LockKeyhole size={17}/></span><div><b>Private by default</b><small>Files stay in your browser in this build.</small></div></div><div className="strip-item"><span className="strip-icon"><ScanSearch size={17}/></span><div><b>Precision-first workflow</b><small>Review and select before making changes.</small></div></div><div className="strip-item"><span className="strip-icon"><Fingerprint size={17}/></span><div><b>Provenance-aware</b><small>Authenticity signals should be preserved.</small></div></div></section>
        <footer id="principles"><span>© 2026 CLEARFRAME AI</span><span>Made for creators who care about the source.</span><a href="#home">Back to top ↑</a></footer>
      </main>
    </div>
  )
}