# CLEARFRAME AI — starter build

A mobile-friendly React/Vite starter for a local-first video workspace.

## Current capabilities
- Load a local video (MP4, MOV, WebM and browser-supported video formats).
- Preview and play the selected video.
- Draw a selection rectangle over a visible watermark area.
- Switch between visible-watermark and provenance-inspection workspaces.
- Keep the selected file in the browser; this starter does not upload it.

## Important limitations
This is the first UI foundation, not a finished AI watermark remover or provenance verifier. It does **not** yet remove or reconstruct watermark pixels, inspect C2PA credentials, or detect invisible watermark signals. Those capabilities require separate, tested processing and verification modules. Provenance/authenticity signals should be preserved, not stripped.

Use only on footage you own or are authorized to edit.

## Development
```bash
npm install
npm run dev
```

## Production build
```bash
npm run build
```

The GitHub Actions workflow sets `GITHUB_PAGES=true`, and Vite uses `/clearframe-ai/` as the Pages base path.
