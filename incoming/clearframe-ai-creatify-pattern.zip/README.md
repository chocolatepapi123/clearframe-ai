# CLEARFRAME AI — Creatify Pattern Prototype

A browser-based video review and cleanup prototype built with React, Vite and TypeScript.

## Deploy on GitHub Pages
This project is compatible with the existing CLEARFRAME ZIP deployment workflow:
- `package.json` is at the ZIP root.
- `npm run build` creates `dist/`.
- `vite.config.ts` uses the `/clearframe-ai/` base path when `GITHUB_PAGES=true`.

## New in this build
- **Creatify Pattern Profile**: samples three points in the video and creates an experimental warm-tint candidate mask.
- **Mask preview**: overlays candidate pixels in magenta so you can visually inspect what the heuristic selected.
- **Coverage stats**: reports the percentage of sampled pixels marked by the heuristic.
- **Clear preview**: removes the diagnostic overlay.

## Important limitations — read before use
The Creatify profile is a **heuristic diagnostic prototype**, not a trained logo/text detector. It uses warm-color thresholds and recurrence across three sampled frames. It can mark orange background details or miss faint watermark pixels. Inspect the preview carefully.

The mask is **not yet connected to removal or export**. Existing export only applies the selected rectangular blur, pixelation or solid-cover effects and records a browser-generated WebM. It does not reconstruct the original background, protect foreground text automatically, or produce an inpainted clean video.

True removal of this repeated semi-transparent watermark requires a stronger segmentation model and video inpainting/reconstruction backend. GitHub Pages alone cannot host that processing engine.

## Run locally
```bash
npm install
npm run dev
```
Build:
```bash
npm run build
```
