import { useEffect, useRef, useState } from 'react'
import { Aperture, Upload, ScanSearch, WandSparkles, Download, ShieldCheck, CircleHelp, Check, X, Play, Pause, RotateCcw, Move, FileVideo, AlertTriangle, Sparkles, SlidersHorizontal } from 'lucide-react'

type Rect = { x:number; y:number; w:number; h:number; label:string; source:'auto'|'manual' }
type Mode = 'soften'|'pixelate'|'cover'

const fmt = (n:number) => `${Math.round(n)}%`

export default function App() {
  const [file,setFile] = useState<File|null>(null)
  const [url,setUrl] = useState('')
  const [rects,setRects] = useState<Rect[]>([])
  const [active,setActive] = useState(0)
  const [mode,setMode] = useState<Mode>('soften')
  const [scanning,setScanning] = useState(false)
  const [scanNote,setScanNote] = useState('No scan yet')
  const [creatifyMaskUrl,setCreatifyMaskUrl] = useState('')
  const [creatifyMaskStats,setCreatifyMaskStats] = useState<{marked:number;sampled:number;coverage:number}|null>(null)
  const [provenance,setProvenance] = useState<string[]>([])
  const [provStatus,setProvStatus] = useState('')
  const [drag,setDrag] = useState<{x:number;y:number}|null>(null)
  const [progress,setProgress] = useState(0)
  const [processing,setProcessing] = useState(false)
  const [exportUrl,setExportUrl] = useState('')
  const [error,setError] = useState('')
  const videoRef = useRef<HTMLVideoElement>(null)
  const stageRef = useRef<HTMLDivElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const fileInput = useRef<HTMLInputElement>(null)

  useEffect(()=>()=>{ if(url) URL.revokeObjectURL(url); if(exportUrl) URL.revokeObjectURL(exportUrl) },[url,exportUrl])

  const loadFile = (f?:File) => {
    if(!f) return
    if(!f.type.startsWith('video/')) { setError('Please choose a video file.'); return }
    setError(''); setFile(f); setUrl(URL.createObjectURL(f)); setRects([]); setActive(0)
    setScanNote('Ready to scan'); setProvenance([]); setProvStatus(''); setExportUrl(''); setProgress(0); setCreatifyMaskUrl(''); setCreatifyMaskStats(null)
  }

  const inspectProvenance = async () => {
    if(!file) return
    setProvStatus('Inspecting file metadata…')
    try {
      const buf = await file.slice(0, Math.min(file.size, 24*1024*1024)).arrayBuffer()
      const bytes = new Uint8Array(buf)
      let binary = ''
      const step = 0x8000
      for(let i=0;i<bytes.length;i+=step) binary += String.fromCharCode(...bytes.subarray(i,Math.min(i+step,bytes.length)))
      const lower = binary.toLowerCase()
      const markers = [
        ['C2PA / Content Credentials', /c2pa|content.?credentials|c2ma|jumbf/.test(lower)],
        ['XMP metadata', /xmpmeta|adobe:ns:meta/.test(lower)],
        ['SynthID reference string', /synthid/.test(lower)],
        ['AI / generator metadata', /generative.?ai|ai.?generated|openai|midjourney|stability.?ai/.test(lower)]
      ].filter(x=>x[1]).map(x=>x[0])
      setProvenance(markers)
      setProvStatus(markers.length ? 'Potential provenance markers found in the inspected file bytes.' : 'No supported provenance marker was found in the inspected portion.')
    } catch { setProvStatus('Could not inspect this file’s metadata in your browser.') }
  }

  const scan = async () => {
    const video=videoRef.current
    if(!video || !file) return
    setScanning(true); setScanNote('Analysing sample frames…'); setError('')
    try {
      if(video.readyState < 2) await new Promise<void>(resolve=>video.addEventListener('loadeddata',()=>resolve(),{once:true}))
      const c=document.createElement('canvas'); c.width=video.videoWidth; c.height=video.videoHeight
      const ctx=c.getContext('2d',{willReadFrequently:true})!
      const duration = Number.isFinite(video.duration) ? video.duration : 0
      const times = duration > 1 ? [Math.min(0.5,duration/4),duration/2,Math.max(0,duration-0.5)] : [0]
      const candidates:{x:number;y:number;w:number;h:number;score:number}[]=[]
      for(const t of times){
        video.currentTime=t
        await new Promise<void>(resolve=>video.addEventListener('seeked',()=>resolve(),{once:true}))
        ctx.drawImage(video,0,0,c.width,c.height)
        const tileW=Math.max(40,Math.floor(c.width*.22)), tileH=Math.max(24,Math.floor(c.height*.14))
        const spots=[
          [0,0],[c.width-tileW,0],[0,c.height-tileH],[c.width-tileW,c.height-tileH],
          [Math.floor((c.width-tileW)/2),0],[Math.floor((c.width-tileW)/2),c.height-tileH]
        ]
        for(const [x,y] of spots){
          const d=ctx.getImageData(x,y,tileW,tileH).data
          let sum=0,sum2=0,edges=0,n=0
          for(let yy=1;yy<tileH;yy+=2) for(let xx=1;xx<tileW;xx+=2){
            const i=(yy*tileW+xx)*4, p=((yy-1)*tileW+xx)*4
            const lum=(d[i]+d[i+1]+d[i+2])/3, prev=(d[p]+d[p+1]+d[p+2])/3
            sum+=lum; sum2+=lum*lum; edges+=Math.abs(lum-prev); n++
          }
          const mean=sum/n, variance=Math.max(0,sum2/n-mean*mean)
          const score=Math.sqrt(variance)*.65+(edges/n)*.35
          candidates.push({x,y,w:tileW,h:tileH,score})
        }
      }
      candidates.sort((a,b)=>b.score-a.score)
      const best=candidates[0]
      const scale=100
      const suggestion:Rect={x:best.x/c.width*scale,y:best.y/c.height*scale,w:best.w/c.width*scale,h:best.h/c.height*scale,label:'Suggested region',source:'auto'}
      setRects([suggestion]); setActive(0)
      setScanNote('Scan complete — review the suggested region')
      video.currentTime=0
    } catch(e) { setError('Automatic scan could not analyse this video. Try selecting the watermark manually.'); setScanNote('Scan unavailable') }
    finally { setScanning(false) }
  }


  // Experimental Creatify-specific diagnostic mask. It highlights pixels whose
  // orange/pink tint resembles the repeating watermark seen in the supplied sample.
  // It is a review mask, not a semantic watermark detector or inpainting engine.
  const scanCreatifyPattern = async () => {
    const video = videoRef.current
    if (!video || !file) return
    setScanning(true)
    setError('')
    setScanNote('Building Creatify pattern mask…')
    try {
      if (video.readyState < 2) {
        await new Promise<void>(resolve => video.addEventListener('loadeddata', () => resolve(), { once: true }))
      }
      const w = Math.min(video.videoWidth, 720)
      const h = Math.round(video.videoHeight * (w / video.videoWidth))
      const sample = document.createElement('canvas')
      sample.width = w; sample.height = h
      const ctx = sample.getContext('2d', { willReadFrequently: true })!
      const originalTime = video.currentTime
      const times = [Math.min(1, Math.max(0, video.duration * .08)), video.duration * .5, Math.max(0, video.duration - .8)]
      const accum = new Uint8Array(w * h)
      let validSamples = 0
      for (const t of times) {
        video.currentTime = t
        await new Promise<void>(resolve => video.addEventListener('seeked', () => resolve(), { once: true }))
        ctx.drawImage(video, 0, 0, w, h)
        const px = ctx.getImageData(0, 0, w, h).data
        for (let i = 0, p = 0; i < px.length; i += 4, p++) {
          const r = px[i], g = px[i + 1], b = px[i + 2]
          // Watermark in the provided sample is a pale warm tint over saturated orange.
          // Exclude near-white/black foreground text and most of the saturated base orange.
          const warmTint = r > 150 && g > 68 && g < 190 && b < 145 &&
            (r - g) > 28 && (g - b) > 12 && (r + g + b) > 300
          if (warmTint) accum[p]++
        }
        validSamples++
      }
      const out = document.createElement('canvas')
      out.width = w; out.height = h
      const octx = out.getContext('2d')!
      const image = octx.createImageData(w, h)
      let marked = 0
      for (let p = 0; p < accum.length; p++) {
        // Require the candidate tint to recur in at least two sampled frames.
        if (accum[p] >= 2) {
          const q = p * 4
          image.data[q] = 255; image.data[q + 1] = 40; image.data[q + 2] = 190; image.data[q + 3] = 145
          marked++
        }
      }
      octx.putImageData(image, 0, 0)
      setCreatifyMaskUrl(out.toDataURL('image/png'))
      setCreatifyMaskStats({ marked, sampled: w * h, coverage: marked / (w * h) * 100 })
      setScanNote(`Diagnostic mask ready · ${((marked / (w * h)) * 100).toFixed(1)}% candidate pixels`)
      video.currentTime = originalTime
    } catch {
      setError('Creatify pattern scan could not complete. Try a shorter video or a smaller file.')
      setScanNote('Creatify scan unavailable')
    } finally {
      setScanning(false)
    }
  }

  const pointerPos=(e:React.PointerEvent<HTMLDivElement>)=>{
    const r=stageRef.current!.getBoundingClientRect()
    return {x:Math.max(0,Math.min(100,(e.clientX-r.left)/r.width*100)),y:Math.max(0,Math.min(100,(e.clientY-r.top)/r.height*100))}
  }
  const startDraw=(e:React.PointerEvent<HTMLDivElement>)=>{
    if(!file || !stageRef.current) return
    if((e.target as HTMLElement).closest('.selection')) return
    const p=pointerPos(e); setDrag(p)
  }
  const finishDraw=(e:React.PointerEvent<HTMLDivElement>)=>{
    if(!drag) return
    const p=pointerPos(e), x=Math.min(drag.x,p.x), y=Math.min(drag.y,p.y)
    const w=Math.abs(p.x-drag.x),h=Math.abs(p.y-drag.y)
    if(w>1.5 && h>1.5){setRects(prev=>[...prev,{x,y,w,h,label:'Manual selection',source:'manual'}]);setActive(rects.length)}
    setDrag(null)
  }

  const exportVideo=async()=>{
    const video=videoRef.current, canvas=canvasRef.current
    if(!video || !canvas || !file) return
    if(!rects.length){setError('Run a scan or select a watermark area first.');return}
    if(!('MediaRecorder' in window)){setError('Video export is not supported by this browser. Try Chrome.');return}
    setError('');setProcessing(true);setProgress(0)
    const w=video.videoWidth,h=video.videoHeight
    canvas.width=w;canvas.height=h
    const ctx=canvas.getContext('2d')!
    const stream=canvas.captureStream(30)
    const sourceStream=(video as HTMLVideoElement & {captureStream?:()=>MediaStream}).captureStream?.()
    sourceStream?.getAudioTracks().forEach(t=>stream.addTrack(t))
    const mime=['video/webm;codecs=vp9,opus','video/webm;codecs=vp8,opus','video/webm'].find(t=>MediaRecorder.isTypeSupported(t))
    const recorder=new MediaRecorder(stream,mime?{mimeType:mime}:undefined)
    const chunks:BlobPart[]=[]
    recorder.ondataavailable=e=>{if(e.data.size)chunks.push(e.data)}
    const done=new Promise<void>(resolve=>recorder.onstop=()=>resolve())
    const draw=()=>{
      if(video.paused || video.ended) return
      ctx.drawImage(video,0,0,w,h)
      rects.forEach(r=>{
        const x=r.x/100*w,y=r.y/100*h,rw=r.w/100*w,rh=r.h/100*h
        if(mode==='soften'){
          ctx.save();ctx.filter='blur(14px)';ctx.drawImage(canvas,x,y,rw,rh,x,y,rw,rh);ctx.restore()
          ctx.fillStyle='rgba(12,16,24,.12)';ctx.fillRect(x,y,rw,rh)
        } else if(mode==='pixelate'){
          const sw=Math.max(2,Math.floor(rw/12)),sh=Math.max(2,Math.floor(rh/12))
          const tmp=document.createElement('canvas');tmp.width=sw;tmp.height=sh
          tmp.getContext('2d')!.drawImage(canvas,x,y,rw,rh,0,0,sw,sh)
          ctx.imageSmoothingEnabled=false;ctx.drawImage(tmp,0,0,sw,sh,x,y,rw,rh);ctx.imageSmoothingEnabled=true
        } else {
          ctx.fillStyle='#101722';ctx.fillRect(x,y,rw,rh)
        }
      })
      setProgress(Math.min(99,video.currentTime/Math.max(video.duration,1)*100))
      requestAnimationFrame(draw)
    }
    recorder.start(250)
    video.currentTime=0
    await video.play()
    draw()
    video.onended=()=>{recorder.stop();setProgress(100)}
    await done
    const blob=new Blob(chunks,{type:recorder.mimeType||'video/webm'})
    setExportUrl(URL.createObjectURL(blob));setProcessing(false);video.pause();video.currentTime=0
  }

  const selected=rects[active]
  return <div className="app-shell">
    <header className="topbar">
      <a className="brand" href="#"><span className="brand-mark"><Aperture size={21}/></span><span>CLEARFRAME<span className="brand-ai"> AI</span><small>VIDEO CLEANUP STUDIO</small></span></a>
      <div className="top-actions"><span className="local-pill"><span/> BROWSER-BASED WORKSPACE</span><button className="help" title="How it works" onClick={()=>alert('CLEARFRAME AI scans for likely visible overlays, lets you select areas manually, and exports a processed copy. Results depend on the video and browser.') }><CircleHelp size={18}/></button></div>
    </header>

    <main>
      <section className="hero">
        <div className="eyebrow"><Sparkles size={14}/> YOUR VIDEO, REFRAMED</div>
        <h1>Make room for the <em>real picture.</em></h1>
        <p>Find visible overlays, choose what needs attention, and export a cleaner copy. You stay in control at every step.</p>
      </section>

      <div className="workspace">
        <aside className="sidebar">
          <div className="side-heading"><span>WORKFLOW</span><span className="step-count">01 — 04</span></div>
          <div className="step active"><span className="step-icon"><Upload size={17}/></span><span><b>Import video</b><small>Choose your source file</small></span><Check size={15} className="step-check"/></div>
          <div className={`step ${file?'active':''}`}><span className="step-icon"><ScanSearch size={17}/></span><span><b>Find watermark</b><small>Scan or select manually</small></span></div>
          <div className="step"><span className="step-icon"><WandSparkles size={17}/></span><span><b>Clean frame</b><small>Choose a processing style</small></span></div>
          <div className="step"><span className="step-icon"><Download size={17}/></span><span><b>Export</b><small>Save your processed video</small></span></div>
          <div className="side-divider"/>
          <div className="privacy-card"><ShieldCheck size={18}/><b>Private by design</b><p>Your source video is processed in your browser. It is not uploaded to a CLEARFRAME server.</p></div>
          <div className="side-foot">CLEARFRAME AI <span>v1.0</span></div>
        </aside>

        <section className="main-panel">
          <div className="panel-top"><div><div className="panel-kicker">01 / SOURCE</div><h2>Your video workspace</h2></div><span className="format-chip"><FileVideo size={14}/> MP4 · MOV · WEBM</span></div>
          {!file ? <div className="dropzone" onClick={()=>fileInput.current?.click()} onDragOver={e=>e.preventDefault()} onDrop={e=>{e.preventDefault();loadFile(e.dataTransfer.files[0])}}>
            <input ref={fileInput} type="file" accept="video/*" hidden onChange={e=>loadFile(e.target.files?.[0])}/>
            <div className="upload-icon"><Upload size={25}/></div><h3>Drop your video here</h3><p>or choose a file from your device</p><button className="primary-btn"><Upload size={16}/> Choose video</button><small>Works best with MP4 · Maximum size depends on your device memory</small>
          </div> : <>
            <div className="video-stage" ref={stageRef} onPointerDown={startDraw} onPointerUp={finishDraw} onPointerCancel={()=>setDrag(null)}>
              <video ref={videoRef} src={url} controls playsInline onLoadedMetadata={()=>{}}/>
              {creatifyMaskUrl && <img className="creatify-mask-overlay" src={creatifyMaskUrl} alt="Experimental Creatify candidate mask preview"/>}
              {rects.map((r,i)=><div key={i} className={`selection ${active===i?'selected':''}`} style={{left:fmt(r.x),top:fmt(r.y),width:fmt(r.w),height:fmt(r.h)}} onClick={e=>{e.stopPropagation();setActive(i)}}><span>{r.source==='auto'?'AUTO SUGGESTION':'MANUAL'} · {i+1}</span></div>)}
              {drag&&<div className="selection drawing" style={{left:fmt(Math.min(drag.x,0)),top:fmt(drag.y),width:0,height:0}}/>}
            </div>
            <div className="video-meta"><span><b>{file.name}</b><small>{(file.size/1024/1024).toFixed(1)} MB</small></span><button className="text-btn" onClick={()=>{setFile(null);setUrl('');setRects([]);setExportUrl('')}}><RotateCcw size={14}/> Replace</button></div>
            <div className="selection-hint"><Move size={15}/> Drag on the video to draw a watermark selection. Tap a box to select it.</div>
            <div className="tool-row"><button className="primary-btn" onClick={scan} disabled={scanning}>{scanning?<span className="spinner"/>:<ScanSearch size={16}/>} {scanning?'Scanning…':'Auto-detect visible overlays'}</button><span className="scan-status">{scanNote}</span></div>
            <div className="creatify-tool">
              <div><b>CREATIFY PATTERN PROFILE</b><small>Experimental multi-frame tint mask for the repeating diagonal mark</small></div>
              <button className="outline-btn" onClick={scanCreatifyPattern} disabled={scanning}>{scanning?'Analysing…':'Generate mask preview'}</button>
              {creatifyMaskStats && <div className="mask-stats"><span>{creatifyMaskStats.coverage.toFixed(2)}% candidate pixels</span><span>{creatifyMaskStats.sampled.toLocaleString()} pixels sampled</span><button onClick={()=>{setCreatifyMaskUrl('');setCreatifyMaskStats(null)}}>Clear preview</button></div>}
            </div>
            {rects.length>0&&<div className="regions">
              <div className="section-label">DETECTED / SELECTED AREAS <span>{rects.length}</span></div>
              {rects.map((r,i)=><div className={`region-row ${active===i?'chosen':''}`} key={i} onClick={()=>setActive(i)}><span className="region-dot"/><span>{r.label}<small>{r.source==='auto'?'Suggested by visual scan':'Selected manually'}</small></span><button title="Remove selection" onClick={e=>{e.stopPropagation();setRects(prev=>prev.filter((_,j)=>j!==i));setActive(0)}}><X size={15}/></button></div>)}
            </div>}
          </>}

          {file&&<div className="processing-card">
            <div className="section-label"><SlidersHorizontal size={14}/> CLEANUP METHOD</div>
            <div className="mode-grid">
              <button className={mode==='soften'?'mode selected-mode':'mode'} onClick={()=>setMode('soften')}><span className="mode-preview blur-preview"/> <b>Soft blur</b><small>Reduce visibility</small></button>
              <button className={mode==='pixelate'?'mode selected-mode':'mode'} onClick={()=>setMode('pixelate')}><span className="mode-preview pixel-preview"/> <b>Pixelate</b><small>Mosaic the region</small></button>
              <button className={mode==='cover'?'mode selected-mode':'mode'} onClick={()=>setMode('cover')}><span className="mode-preview cover-preview"/> <b>Cover</b><small>Solid fill</small></button>
            </div>
            <div className="notice"><AlertTriangle size={16}/><p>These browser-based methods soften, pixelate or cover selected rectangles. The Creatify mask preview is diagnostic only; it is not yet connected to pixel-level reconstruction or export.</p></div>
            <button className="export-btn" onClick={exportVideo} disabled={processing||!rects.length}><WandSparkles size={17}/>{processing?'Processing video…':'Process & export video'}<Download size={16}/></button>
            {processing&&<div className="progress"><div style={{width:`${progress}%`}}/></div>}
            {exportUrl&&<div className="export-ready"><Check size={17}/><span><b>Your processed video is ready</b><small>Export format: WebM</small></span><a href={exportUrl} download="clearframe-cleaned.webm"><Download size={15}/> Download</a></div>}
          </div>}

          {error&&<div className="error-msg"><AlertTriangle size={16}/>{error}</div>}
        </section>

        <aside className="inspector">
          <div className="panel-kicker">02 / INTELLIGENCE</div><h2>Video inspection</h2>
          <div className="inspect-card">
            <div className="inspect-title"><span className="inspect-icon"><ScanSearch size={17}/></span><b>Visible overlay scan</b></div>
            <p>General scan suggests regions. The Creatify profile separately highlights recurring warm-tint pixels across three sampled frames. It can include false positives.</p>
            <div className="inspect-result"><span className={rects.length?'result-dot on':'result-dot'}/>{rects.length?`${rects.length} area(s) selected`:'Awaiting video scan'}</div>
          </div>
          <div className="inspect-card provenance-card">
            <div className="inspect-title"><span className="inspect-icon purple"><ShieldCheck size={17}/></span><b>AI provenance check</b></div>
            <p>Looks for supported metadata strings such as C2PA and XMP. This is a basic file scan, not a full standards validator.</p>
            <button className="outline-btn" disabled={!file} onClick={inspectProvenance}>Inspect provenance <ScanSearch size={14}/></button>
            {provStatus&&<div className="prov-result">{provStatus}{provenance.map(p=><span key={p} className="marker"><Check size={12}/>{p}</span>)}</div>}
          </div>
          <div className="trust-note"><ShieldCheck size={17}/><span><b>Authenticity matters</b><small>CLEARFRAME does not remove invisible authenticity or provenance signals. A scan with no matches is not proof that a video has no AI watermark.</small></span></div>
          <div className="inspector-foot">BUILT FOR CREATOR CONTROL <span>✳</span></div>
        </aside>
      </div>
      <footer><span>© 2026 CLEARFRAME AI</span><span>Made for careful editing <i>·</i> Use only on content you own or are authorised to edit.</span></footer>
    </main>
    <canvas ref={canvasRef} className="hidden-canvas"/>
  </div>
}